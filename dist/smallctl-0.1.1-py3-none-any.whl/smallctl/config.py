from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any

from .config_support import (
    LOCAL_CONFIG,
    _apply_config_aliases,
    _apply_typed_config_values,
    _env_config,
    _normalize_graph_checkpointer,
    _normalize_run_mode,
    _read_yaml,
    _to_bool,
)
from .phases import normalize_phase
from .presets import get_preset_defaults
from .provider_profiles import resolve_provider_profile


PROVIDER_PROFILES: dict[str, dict[str, Any]] = {
    "auto": {"runtime_context_probe": True},
    "generic": {"runtime_context_probe": True},
    "openai": {
        "chat_endpoint": "/chat/completions",
        "reasoning_mode": "off",
        "runtime_context_probe": False,
    },
    "ollama": {
        "chat_endpoint": "/chat/completions",
        "reasoning_mode": "off",
        "runtime_context_probe": False,
    },
    "vllm": {
        "chat_endpoint": "/chat/completions",
        "reasoning_mode": "field",
        "runtime_context_probe": False,
    },
    "lmstudio": {
        "chat_endpoint": "/chat/completions",
        "reasoning_mode": "tags",
        "runtime_context_probe": False,
    },
    "openrouter": {
        "chat_endpoint": "/chat/completions",
        "reasoning_mode": "off",
        "runtime_context_probe": True,
    },
    "llamacpp": {
        "chat_endpoint": "/chat/completions",
        "runtime_context_probe": True,
    },
}


@dataclass
class SmallctlConfig:
    endpoint: str = "http://localhost:8000/v1"
    model: str = "qwen3.5:4b"
    phase: str = "explore"
    provider_profile: str = "generic"
    run_mode: str = "auto"
    indexer: bool = False
    tool_profiles: list[str] | None = None
    reasoning_mode: str = "auto"
    thinking_visibility: bool = True
    thinking_start_tag: str = "<think>"
    thinking_end_tag: str = "</think>"
    chat_endpoint: str = "/chat/completions"
    checkpoint_on_exit: bool = False
    checkpoint_path: str | None = None
    graph_checkpointer: str = "memory"
    graph_checkpoint_path: str | None = None
    graph_node_timeout_sec: int = 300
    graph_model_call_timeout_sec: int = 600
    graph_dispatch_tools_timeout_sec: int = 300
    graph_idle_watchdog_sec: int = 300
    graph_recursion_limit: int = 1024
    graph_coding_recursion_limit: int = 2048
    needs_human_timeout_sec: int = 600
    restore_graph_state: bool = False
    graph_thread_id: str | None = None
    fresh_run: bool = False
    fresh_run_turns: int = 1
    planning_mode: bool = False
    contract_flow_ui: bool = False
    staged_reasoning: bool = False
    staged_execution_enabled: bool = False
    staged_step_prompt_tokens: int = 4096
    tool_plan_runtime_enabled: bool = False
    tool_plan_auto_select: bool = False
    tool_plan_readonly_only: bool = True
    tool_plan_max_steps: int = 6
    tool_plan_max_repair_attempts: int = 1
    schema_validation_max_repair_attempts: int = 2
    tool_plan_observation_token_limit: int = 900
    tool_plan_max_observation_chars_per_step: int = 600
    tool_plan_solver_fresh_output_limit: int = 1200
    tool_plan_allow_web: bool = True
    tool_plan_allow_artifact_read: bool = True
    tool_plan_allow_git: bool = False
    tool_plan_fallback_to_loop_on_invalid_plan: bool = True
    tool_dag_enabled: bool = True
    tool_dag_max_parallel: int = 4
    tool_dag_timeout_sec: int = 30
    tool_dag_preserve_result_order: bool = True
    solver_refine_enabled: bool = False
    solver_refine_max_passes: int = 1
    solver_refine_on_final_answer: bool = True
    solver_refine_on_patch_plan: bool = True
    solver_refine_on_task_complete: bool = True
    solver_refine_token_budget: int = 700
    rewoo_lane_frames_enabled: bool = False
    rewoo_planner_frame_enabled: bool = False
    rewoo_solver_frame_enabled: bool = False
    rewoo_refiner_frame_enabled: bool = False
    rewoo_frame_token_budget: int = 1200
    test_time_scaling_enabled: bool = False
    test_time_scaling_runtimes: list[str] = field(default_factory=lambda: ["staged_execution"])
    test_time_scaling_trigger: str = "retry_or_explicit"
    test_time_scaling_max_candidates: int = 3
    test_time_scaling_min_candidates: int = 2
    test_time_scaling_policy: str = "proposal_then_execute"
    test_time_scaling_strategy: str = "diverse_nudges"
    test_time_scaling_score_threshold: float = 0.85
    test_time_scaling_parallel_max: int = 1
    test_time_scaling_timeout_sec: int = 120
    test_time_scaling_mutating_parallel_enabled: bool = False
    test_time_scaling_all_fail_action: str = "fallback_normal_retry"
    escalation_enabled: bool = False
    escalation_expose_tool: bool = True
    escalation_auto_trigger: bool = False
    escalation_endpoint: str | None = None
    escalation_model: str | None = None
    escalation_provider_profile: str = "auto"
    escalation_api_key: str | None = None
    escalation_api_key_env: str | None = None
    escalation_chat_endpoint: str = "/chat/completions"
    escalation_max_prompt_chars: int = 48000
    escalation_max_response_tokens: int = 1600
    escalation_temperature: float = 0.2
    escalation_timeout_sec: int = 120
    escalation_max_per_task: int = 3
    escalation_cooldown_turns: int = 2
    escalation_repeated_failure_threshold: int = 2
    escalation_require_tool_plan_evidence: bool = True
    escalation_redact_secrets: bool = True
    log_file: str | None = None
    debug: bool = False
    cleanup: bool = False
    tui: bool = False
    task: str | None = None
    config_path: str | None = None
    preset: str | None = None
    api_key: str | None = "local-dev-key"
    context_limit: int | None = None
    max_prompt_tokens: int | None = None
    max_prompt_tokens_explicit: bool = False
    reserve_completion_tokens: int = 1024
    reserve_tool_tokens: int = 512
    first_token_timeout_sec: int | None = None
    healthcheck_url: str | None = None
    restart_command: str | None = None
    startup_grace_period_sec: int = 20
    max_restarts_per_hour: int = 2
    backend_healthcheck_url: str | None = None
    backend_restart_command: str | None = None
    backend_unload_command: str | None = None
    backend_healthcheck_timeout_sec: int = 5
    backend_restart_grace_sec: int = 20
    summarize_at_ratio: float = 0.8
    recent_message_limit: int = 6
    max_summary_items: int = 3
    max_artifact_snippets: int = 4
    artifact_snippet_token_limit: int = 400
    multi_file_artifact_snippet_limit: int = 8
    multi_file_primary_file_limit: int = 3
    remote_task_artifact_snippet_limit: int = 8
    remote_task_primary_file_limit: int = 2
    compatibility_warnings: list[str] = field(default_factory=list)
    runtime_context_probe: bool = True
    summarizer_endpoint: str | None = None
    summarizer_model: str | None = None
    summarizer_api_key: str | None = None
    min_exploration_steps: int = 1
    artifact_summarization_threshold: int = 1200
    chunk_mode_min_bytes: int = 4096
    chunk_mode_new_file_only: bool = True
    chunk_mode_supported_models: list[str] = field(default_factory=lambda: ["qwen3.5", "llama3.1", "deepseek-v3"])
    small_model_soft_write_chars: int = 2000
    small_model_hard_write_chars: int = 4000
    new_file_chunk_mode_line_estimate: int = 100
    allow_multi_section_turns_for_small_edits: bool = True
    failed_local_patch_limit: int = 2
    enable_write_intent_recovery: bool = True
    enable_assistant_code_write_recovery: bool = True
    write_recovery_min_confidence: str = "high"
    write_recovery_allow_raw_text_targets: bool = True
    loop_guard_enabled: bool = True
    loop_guard_stagnation_threshold: int = 3
    loop_guard_level2_threshold: int = 5
    loop_guard_recent_writes_limit: int = 5
    loop_guard_tail_lines: int = 50
    loop_guard_similarity_threshold: float = 0.9
    loop_guard_cumulative_write_gate: bool = True
    loop_guard_checkpoint_gate: bool = True
    loop_guard_diff_gate: bool = True
    fama_enabled: bool = True
    fama_mode: str = "lite"
    fama_default_ttl_steps: int = 2
    fama_max_active_mitigations: int = 2
    fama_signal_window: int = 8
    fama_done_gate_on_failure: bool = True
    fama_capsule_token_budget: int = 180
    fama_llm_judge_enabled: bool = False
    fama_llm_judge_min_severity: int = 3
    fama_disabled: bool = False
    reflexion_enabled: bool = True
    reflexion_max_items: int = 5
    reflexion_inject_top_k: int = 3
    reflexion_persist_cross_task: bool = False
    reflexion_min_failure_severity: str = "warning"
    subtask_ledger_enabled: bool = True
    subtask_max_active: int = 1
    subtask_max_history: int = 12
    subtask_inject_completed_limit: int = 3
    sudo_password: str | None = None
    verbose: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def resolve_config(cli: dict[str, Any]) -> SmallctlConfig:
    # Source precedence (before provider defaults):
    # user config path -> local config -> env/.env -> CLI
    env_cfg = _env_config()
    user_cfg: dict[str, Any] = {}
    local_cfg: dict[str, Any] = {}

    user_config_path = cli.get("config_path") or env_cfg.get("config_path")
    if user_config_path:
        user_cfg = _read_yaml(Path(user_config_path))
        user_cfg["config_path"] = user_config_path
    local_cfg = _read_yaml(Path.cwd() / LOCAL_CONFIG)

    merged: dict[str, Any] = {}
    if "provider_profile" not in merged:
        merged["provider_profile"] = "auto"

    cli_clean = {k: v for k, v in cli.items() if v is not None}
    if "tool_profiles" in cli_clean:
        from .tools.profiles import parse_public_profiles

        cli_clean["tool_profiles"] = parse_public_profiles(cli_clean["tool_profiles"])
    _apply_typed_config_values(cli_clean)
    _apply_config_aliases(cli_clean)

    explicit_merged: dict[str, Any] = {}
    explicit_merged.update(user_cfg)
    explicit_merged.update(local_cfg)
    explicit_merged.update(env_cfg)
    explicit_merged.update(cli_clean)
    preset_name = str(explicit_merged.get("preset") or "").strip().lower() or None
    preset_defaults = get_preset_defaults(preset_name)

    if preset_defaults:
        merged.update(preset_defaults)
    merged.update(user_cfg)
    merged.update(local_cfg)
    merged.update(env_cfg)
    merged.update(cli_clean)
    if preset_name:
        merged["preset"] = preset_name
    _apply_typed_config_values(merged)
    _apply_config_aliases(merged)
    if merged.get("staged_reasoning") and "staged_execution_enabled" not in explicit_merged:
        merged["staged_execution_enabled"] = True

    explicit_prompt_budget = "max_prompt_tokens" in explicit_merged
    merged["max_prompt_tokens_explicit"] = explicit_prompt_budget
    if not explicit_prompt_budget and "context_limit" in merged:
        merged["max_prompt_tokens"] = merged["context_limit"]
    compatibility_warnings: list[str] = []
    if "context_limit" in merged and not explicit_prompt_budget:
        compatibility_warnings.append(
            "Legacy SMALLCTL_CONTEXT_LIMIT is being treated as SMALLCTL_MAX_PROMPT_TOKENS."
        )
    elif "context_limit" in merged and explicit_prompt_budget:
        compatibility_warnings.append(
            "Legacy SMALLCTL_CONTEXT_LIMIT remains set; prefer SMALLCTL_MAX_PROMPT_TOKENS for per-turn budgeting."
        )
    if preset_name and not preset_defaults:
        compatibility_warnings.append(f"Unknown preset '{preset_name}' ignored.")
    if _to_bool(merged.get("escalation_enabled")) and (
        not str(merged.get("escalation_endpoint") or "").strip()
        or not str(merged.get("escalation_model") or "").strip()
    ):
        compatibility_warnings.append(
            "Escalation is enabled but escalation_endpoint or escalation_model is missing; escalation tool calls will fail until configured."
        )
    merged["phase"] = normalize_phase(str(merged.get("phase", "explore")))
    merged["run_mode"] = _normalize_run_mode(merged.get("run_mode", "auto"))
    merged["graph_checkpointer"] = _normalize_graph_checkpointer(merged.get("graph_checkpointer", "memory"))
    if merged.get("graph_checkpoint_path") and merged["graph_checkpointer"] == "memory":
        merged["graph_checkpointer"] = "file"
    if merged.get("fresh_run"):
        merged["restore_graph_state"] = False
    _apply_provider_profile(merged, explicit_merged, compatibility_warnings)
    profile = str(merged.get("provider_profile", "auto")).strip().lower()
    if profile == "lmstudio":
        if not str(merged.get("backend_unload_command") or "").strip() and not str(
            merged.get("backend_restart_command") or ""
        ).strip():
            compatibility_warnings.append(
                "LM Studio native API unload will be attempted automatically; configure SMALLCTL_BACKEND_RESTART_COMMAND if you want restart fallback when unload does not recover."
            )
        configured_timeout = merged.get("first_token_timeout_sec")
        if configured_timeout is not None:
            try:
                normalized_timeout = float(configured_timeout)
            except (TypeError, ValueError):
                normalized_timeout = 0.0
            if 0.0 < normalized_timeout < 45.0:
                compatibility_warnings.append(
                    "LM Studio first_token_timeout_sec below 45s may cause false 'backend wedged' detections on slower local generations."
                )
    merged["compatibility_warnings"] = compatibility_warnings

    allowed_keys = {f.name for f in fields(SmallctlConfig)}
    unknown_keys = sorted(k for k in merged if k not in allowed_keys)
    if unknown_keys:
        compatibility_warnings.append(f"Ignoring unsupported config keys: {', '.join(unknown_keys)}.")
    filtered = {k: v for k, v in merged.items() if k in allowed_keys}
    return SmallctlConfig(**filtered)


def _apply_provider_profile(
    merged: dict[str, Any],
    explicit_merged: dict[str, Any],
    compatibility_warnings: list[str],
) -> None:
    profile, profile_warnings = resolve_provider_profile(
        merged.get("endpoint"),
        merged.get("model"),
        merged.get("provider_profile", "auto"),
    )
    if profile_warnings:
        compatibility_warnings.extend(profile_warnings)
    merged["provider_profile"] = profile
    profile_defaults = PROVIDER_PROFILES.get(profile, {})
    for key, value in profile_defaults.items():
        if key not in explicit_merged:
            merged[key] = value
